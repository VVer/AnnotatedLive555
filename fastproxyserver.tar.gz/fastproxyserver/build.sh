 #!/bin/sh
 cd  src
 make && make clean && mv fastproxyserver ../bin
