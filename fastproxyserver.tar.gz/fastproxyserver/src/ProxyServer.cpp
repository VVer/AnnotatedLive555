#include "ProxyServer.h"
#include "ProxyServerMediaSession.hh"

FastProxyServer::FastProxyServer(UsageEnvironment& env, int ourSocket, Port ourPort,
	UserAuthenticationDatabase* authDatabase, UserAuthenticationDatabase* authDatabaseForREGISTER,
	unsigned reclamationTestSeconds,
	int streamRTPOverTCP, int verbosityLevelForProxying) :
	RTSPServerWithREGISTERProxying(env, ourSocket, ourPort, authDatabase, authDatabaseForREGISTER, reclamationTestSeconds,
	streamRTPOverTCP, verbosityLevelForProxying)
{
 	
}

FastProxyServer::~FastProxyServer()
{
 
}


FastProxyServer* FastProxyServer::createNew(UsageEnvironment& env, Port ourPort,
	UserAuthenticationDatabase* authDatabase,
	UserAuthenticationDatabase* authDatabaseForREGISTER,
	unsigned reclamationTestSeconds,
	int streamRTPOverTCP,
	int verbosityLevelForProxying)
{
	int ourSocket = setUpOurSocket(env, ourPort);
	if (ourSocket == -1) return NULL;

	//��ourPortд����ʱ�ļ�����ȥ
	FILE *fp = fopen("proxyserver.port", "w");
	fprintf(fp, "%d", ntohs(ourPort.num()));
	fclose(fp);

	return new FastProxyServer(env, ourSocket, ourPort, authDatabase, authDatabaseForREGISTER, reclamationTestSeconds,
		streamRTPOverTCP, verbosityLevelForProxying);
}

char const*  FastProxyServer::allowedCommandNames()
{
	return RTSPServer::allowedCommandNames();
}
void FastProxyServer::implementCmd_REGISTER(char const* url, char const* urlSuffix, int socketToRemoteServer,
	int deliverViaTCP, char const* proxyURLSuffix)
{
	loadConfigureFile();
}

void  FastProxyServer::loadConfigureFile0()
{

	UsageEnvironment& env = envir();
	env << "load configuration file " << "\n";
	char line[1024];
	char rtspStreamName[512];
	char proxiedStreamURL[512];
	FILE * conf = fopen("conf", "r");
	if (conf == NULL)
	{
		fprintf(stderr, "Can not open conf file!\n");

		return;
	}
	memset(line, 0, sizeof(line));
	while (fgets(line, 1000, conf) != NULL)
	{
		memset(rtspStreamName, 0, 512);
		memset(proxiedStreamURL, 0, 512);

		sscanf(line, "%[^ ] %[^# ]", proxiedStreamURL, rtspStreamName);
		ServerMediaSession* sms = lookupServerMediaSession(rtspStreamName);
		if (sms == NULL)  //�����ý�岻���ڣ������������
		{
			sms = ProxyServerMediaSession::createNew(env, this,
				proxiedStreamURL, rtspStreamName,
				NULL, NULL, 0, 0);
			addServerMediaSession(sms);

			char* proxyStreamURL = rtspURL(sms);
			env << "Դ��Ƶ����ַ��[" << proxiedStreamURL << "]\n";
			env << "\t������Ƶ����ַ: [" << proxyStreamURL << "]\n";
			delete[] proxyStreamURL;
		}
		else
		{
			env << "��Ƶ��[" << rtspStreamName << "]�Ѿ�����\n";
		}
	}
	fclose(conf);
}

#include <vector>
#include <string>
#include<algorithm>
void  FastProxyServer::loadConfigureFile()
{

	static int firstload = 1;
	std::vector<std::string> streamNames;
	UsageEnvironment& env = envir();
#ifdef DEBUG
	env << "load configuration file " << "\n";
#endif
	char line[512];
	char rtspStreamName[256];
	char proxiedStreamURL[256];
	char username[128];
	char passwd[128];

	FILE * conf = fopen("conf", "r");
	if (conf == NULL)
	{
		fprintf(stderr, "Can not open conf file!\n");

		return;
	}
	memset(line, 0, sizeof(line));
	//����url
	while (fgets(line, sizeof(line), conf) != NULL)
	{
		memset(rtspStreamName, 0, sizeof(rtspStreamName));
		memset(proxiedStreamURL, 0, sizeof(proxiedStreamURL));
		memset(username, 0, sizeof(username));
		memset(passwd,0,sizeof(passwd));

		sscanf(line, "%[^ ] %[^# ]", proxiedStreamURL, rtspStreamName);
		ServerMediaSession* sms = lookupServerMediaSession(rtspStreamName);
		streamNames.push_back(std::string(rtspStreamName));	  //��
		if (sms == NULL)  //�����ý�岻���ڣ������������
		{
			sms = ProxyServerMediaSession::createNew(env, this,
				proxiedStreamURL, rtspStreamName,
				NULL, NULL, 0, 0);
			addServerMediaSession(sms);

			char* proxyStreamURL = rtspURL(sms);
			env << "Դ��Ƶ����ַ��[" << proxiedStreamURL << "]\n";
			env << "\t������Ƶ����ַ: [" << proxyStreamURL << "]\n";
			delete[] proxyStreamURL;
		}
		else
		{
			env << "��Ƶ��[" << rtspStreamName << "]�Ѿ�����\n";
		}
	}
	fclose(conf);
	
	if (!firstload)	 //ɾ�������ڵ���   ���sms��������	streamNames ���Ҳ���������Ϊ������Ѿ���ɾ���� ����Ҫ�ڴ˴�ɾ����sms
	{
		ServerMediaSession* sms = NULL;
		ServerMediaSessionIterator *smsiter = new ServerMediaSessionIterator(*this);

		while (NULL != (sms = smsiter->next()))
		{

			if (streamNames.end() == std::find(streamNames.begin(), streamNames.end(), sms->streamName())) //δ�ҵ�����������
			{
				env << "ɾ����Ƶ��[" << sms->streamName() << "]\n";
				deleteServerMediaSession(sms);
			}

		}
		delete smsiter;
	}
	

}