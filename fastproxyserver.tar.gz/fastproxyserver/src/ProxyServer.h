#pragma once
#include "RTSPServer.hh"
class FastProxyServer :public RTSPServerWithREGISTERProxying
{
public:
	static FastProxyServer* createNew(UsageEnvironment& env, Port ourPort = 554,
		UserAuthenticationDatabase* authDatabase = NULL,
		UserAuthenticationDatabase* authDatabaseForREGISTER = NULL,
		unsigned reclamationTestSeconds = 65,
		int streamRTPOverTCP = False,
		int verbosityLevelForProxying = 0);
	void loadConfigureFile0();
	void loadConfigureFile();
protected:
	FastProxyServer(UsageEnvironment& env, int ourSocket, Port ourPort,
		UserAuthenticationDatabase* authDatabase, UserAuthenticationDatabase* authDatabaseForREGISTER,
		unsigned reclamationTestSeconds,
		int streamRTPOverTCP, int verbosityLevelForProxying);
	virtual ~FastProxyServer();

protected: // redefined virtual functions
	
	virtual void implementCmd_REGISTER(char const* url, char const* urlSuffix, int socketToRemoteServer,
		int deliverViaTCP, char const* proxyURLSuffix);
	virtual char const* allowedCommandNames();
	
 

};